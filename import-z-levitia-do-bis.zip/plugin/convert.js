/* Levitio export.xlsx → BIS attendee CSV */

const BIS_COLUMNS = [
  "first_name",
  "last_name",
  "email",
  "phone",
  "birthday",
  "nickname",
  "street",
  "city",
  "zip_code",
  "birth_name",
  "health_issues",
  "note",
  "subscribed_to_newsletter",
  "health_insurance_company",
  "close_person_first_name",
  "close_person_last_name",
  "close_person_email",
  "close_person_phone",
];

const HEADER_ALIASES = {
  first_name: ["jmeno", "first name", "firstname", "first_name", "given name"],
  last_name: ["prijmeni", "last name", "lastname", "last_name", "surname"],
  birthday: [
    "narozeni",
    "datum narozeni",
    "birthday",
    "birth date",
    "birthdate",
    "date of birth",
    "datum narozenia",
  ],
};

function normalizeHeader(value) {
  return String(value == null ? "" : value)
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ");
}

function excelSerialToISO(serial) {
  const days = Math.floor(Number(serial));
  if (!Number.isFinite(days)) return "";
  const ms = Date.UTC(1899, 11, 30) + days * 86400000;
  const dt = new Date(ms);
  const y = dt.getUTCFullYear();
  const m = String(dt.getUTCMonth() + 1).padStart(2, "0");
  const d = String(dt.getUTCDate()).padStart(2, "0");
  return y + "-" + m + "-" + d;
}

function formatDateParts(year, month, day) {
  const y = Number(year);
  const m = Number(month);
  const d = Number(day);
  if (!y || m < 1 || m > 12 || d < 1 || d > 31) return null;
  return (
    String(y).padStart(4, "0") +
    "-" +
    String(m).padStart(2, "0") +
    "-" +
    String(d).padStart(2, "0")
  );
}

function parseBirthday(value) {
  if (value == null || value === "") return { iso: "", warning: null };

  if (value instanceof Date && !isNaN(value.getTime())) {
    return {
      iso: formatDateParts(
        value.getFullYear(),
        value.getMonth() + 1,
        value.getDate()
      ),
      warning: null,
    };
  }

  if (typeof value === "number" && Number.isFinite(value)) {
    const iso = excelSerialToISO(value);
    return { iso: iso, warning: iso ? null : "datum narození se nepodařilo přečíst" };
  }

  const text = String(value).trim();
  if (!text) return { iso: "", warning: null };

  let match = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (match) {
    const iso = formatDateParts(match[1], match[2], match[3]);
    return { iso: iso || text, warning: iso ? null : "neznámý formát data: " + text };
  }

  match = text.match(/^(\d{1,2})\s*[.\-/]\s*(\d{1,2})\s*[.\-/]\s*(\d{4})$/);
  if (match) {
    const iso = formatDateParts(match[3], match[2], match[1]);
    return { iso: iso || text, warning: iso ? null : "neznámý formát data: " + text };
  }

  if (/^\d+(\.\d+)?$/.test(text)) {
    const iso = excelSerialToISO(Number(text));
    if (iso) return { iso: iso, warning: null };
  }

  return { iso: text, warning: "neznámý formát data: " + text };
}

function findHeader(rows) {
  for (let r = 0; r < rows.length; r++) {
    const row = rows[r] || [];
    const indexes = { first_name: -1, last_name: -1, birthday: -1 };
    for (let c = 0; c < row.length; c++) {
      const key = normalizeHeader(row[c]);
      if (!key) continue;
      for (const field of Object.keys(HEADER_ALIASES)) {
        if (indexes[field] === -1 && HEADER_ALIASES[field].indexOf(key) !== -1) {
          indexes[field] = c;
        }
      }
    }
    if (indexes.first_name !== -1 && indexes.last_name !== -1) {
      return { rowIndex: r, indexes: indexes };
    }
  }
  return null;
}

function cellText(value) {
  if (value == null) return "";
  return String(value).replace(/\s+/g, " ").trim();
}

function convertRows(rows) {
  const header = findHeader(rows);
  if (!header) {
    return {
      ok: false,
      error:
        "Nenašly se sloupce Jméno a Příjmení. Nad hlavičkou může být název výpravy. Hlavička má obsahovat Jméno, Příjmení a Narození.",
      attendees: [],
      warnings: [],
    };
  }

  const attendees = [];
  const warnings = [];
  if (header.indexes.birthday === -1) {
    warnings.push("Sloupec Narození se nenašel. Datum narození zůstane prázdné.");
  }

  for (let r = header.rowIndex + 1; r < rows.length; r++) {
    const row = rows[r] || [];
    const firstName = cellText(row[header.indexes.first_name]);
    const lastName = cellText(row[header.indexes.last_name]);
    const rawBirthday =
      header.indexes.birthday === -1 ? "" : row[header.indexes.birthday];
    const birthday = parseBirthday(rawBirthday);

    if (!firstName && !lastName && !birthday.iso) continue;

    if (birthday.warning) {
      warnings.push("Řádek " + (r + 1) + ": " + birthday.warning);
    }

    const record = {};
    for (let i = 0; i < BIS_COLUMNS.length; i++) record[BIS_COLUMNS[i]] = "";
    record.first_name = firstName;
    record.last_name = lastName;
    record.birthday = birthday.iso || "";
    attendees.push(record);
  }

  return {
    ok: true,
    error: null,
    attendees: attendees,
    warnings: warnings,
    headerRow: header.rowIndex + 1,
  };
}

function csvEscape(value) {
  const text = value == null ? "" : String(value);
  if (/[",\r\n]/.test(text)) return '"' + text.replace(/"/g, '""') + '"';
  return text;
}

function toCsv(attendees) {
  const lines = [BIS_COLUMNS.join(",")];
  for (let i = 0; i < attendees.length; i++) {
    const row = attendees[i];
    const cells = [];
    for (let c = 0; c < BIS_COLUMNS.length; c++) {
      cells.push(csvEscape(row[BIS_COLUMNS[c]]));
    }
    lines.push(cells.join(","));
  }
  return lines.join("\r\n") + "\r\n";
}

function sheetToRows(XLSX, workbook, sheetName) {
  const sheet = workbook.Sheets[sheetName];
  return XLSX.utils.sheet_to_json(sheet, {
    header: 1,
    raw: true,
    defval: "",
    blankrows: false,
  });
}

const api = {
  BIS_COLUMNS: BIS_COLUMNS,
  convertRows: convertRows,
  toCsv: toCsv,
  sheetToRows: sheetToRows,
  parseBirthday: parseBirthday,
};

if (typeof module !== "undefined" && module.exports) {
  module.exports = api;
}
if (typeof window !== "undefined") {
  window.BisConvert = api;
}
