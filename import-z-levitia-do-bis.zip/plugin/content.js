// BIS Levitio import – content script
// Na stránce uzavření akce načte export.xlsx, převede ho stejně jako web
// a přidá nalezené uživatele mezi účastníky.

(function () {
  'use strict';

  const CZECH_MONTHS = [
    'ledna', 'února', 'března', 'dubna', 'května', 'června',
    'července', 'srpna', 'září', 'října', 'listopadu', 'prosince'
  ];

  function isClosePage() {
    return /^\/org\/akce\/\d+\/uzavrit\/?$/.test(location.pathname);
  }

  let pushedEl = null;

  function clearPush() {
    if (!pushedEl) return;
    pushedEl.style.marginTop = pushedEl.dataset.bisPrevMarginTop || '';
    delete pushedEl.dataset.bisPrevMarginTop;
    delete pushedEl.dataset.bisPushed;
    pushedEl = null;
  }

  function removeUI() {
    clearPush();
    document.getElementById('bis-csv-panel')?.remove();
    document.getElementById('bis-csv-strut')?.remove();
    document.getElementById('bis-dup-modal')?.remove();
    document.getElementById('bis-stats-card')?.remove();
    document.querySelectorAll('[data-bis-stats-hidden]').forEach(el => {
      el.style.removeProperty('display');
      delete el.dataset.bisStatsHidden;
    });
  }

  function elementText(el) {
    return el.textContent.replace(/\s+/g, ' ').trim();
  }

  function visibleHeadings() {
    const root = document.getElementById('root');
    if (!root) return [];
    return [...root.querySelectorAll('h1,h2,h3,h4,h5,h6')].filter(el => {
      if (el.closest('#bis-csv-panel, #bis-dup-modal')) return false;
      const rect = el.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    });
  }

  function headingsMatching(pattern) {
    return visibleHeadings().filter(el => {
      const text = elementText(el);
      return text.length <= 80 && pattern.test(text);
    });
  }

  function spotBeforeUcastnici() {
    const prihlaseni = headingsMatching(/^Přihlášení\s*\*?$/);
    const ucastnici = headingsMatching(/^Účastní(?:ci|ctvo)\s*\*?$/);
    const root = document.getElementById('root');
    let target = null;
    if (ucastnici.length && prihlaseni.length) {
      target = ucastnici.find(el => prihlaseni.some(item => item.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING));
    }
    target = target || ucastnici[ucastnici.length - 1] || null;
    if (!target) return null;

    const pri = prihlaseni[0];
    let node = target;
    while (node.parentElement && node.parentElement !== root && node.parentElement !== document.body) {
      const parent = node.parentElement;
      if (pri && parent.contains(pri) && !node.contains(pri)) break;
      const parentRect = parent.getBoundingClientRect();
      if (parentRect.width > window.innerWidth - 24 && parentRect.height > window.innerHeight * 0.9) break;
      node = parent;
    }
    if (!node.parentElement) return null;
    return { parent: node.parentElement, before: node };
  }

  function settleBox(box) {
    box.hidden = false;
    box.style.position = 'static';
    box.style.top = 'auto';
    box.style.left = 'auto';
    box.style.right = 'auto';
    box.style.transform = 'none';
    box.style.zIndex = 'auto';
    box.style.width = '100%';
    box.style.maxWidth = '100%';
    box.style.margin = '16px 0';
  }

  function participantHeading() {
    const root = document.getElementById('root');
    if (!root) return null;
    const marked = root.querySelector('[data-bis-ucastnictvo]');
    if (marked && !marked.closest('#bis-csv-panel, #bis-dup-modal')) return marked;
    const candidates = [...root.querySelectorAll('h1,h2,h3,h4,h5,h6')].filter(el => {
      if (el.closest('#bis-csv-panel, #bis-dup-modal')) return false;
      return /^Účastní(?:ci|ctvo)\s*\*?$/.test(elementText(el));
    });
    candidates.sort((a, b) => {
      if (a.contains(b)) return 1;
      if (b.contains(a)) return -1;
      return 0;
    });
    return candidates[0] || null;
  }

  function participantTable() {
    const root = document.getElementById('root');
    if (!root) return null;
    return [...root.querySelectorAll('table')].find(table => {
      if (table.closest('#bis-csv-panel, #bis-dup-modal')) return false;
      const headers = [...table.querySelectorAll('th, [role="columnheader"]')].map(el => elementText(el).toLowerCase());
      return headers.includes('jméno a příjmení') && headers.includes('adresa');
    }) || null;
  }

  function layoutPanel() {
    clearPush();
    document.getElementById('bis-dup-modal')?.remove();
    const panel = document.getElementById('bis-csv-panel');
    if (!isClosePage() || !panel) return;

    const heading = participantHeading();
    const table = participantTable();
    if (!heading && !table) {
      panel.hidden = true;
      return;
    }

    const wasHidden = panel.hidden;
    settleBox(panel);
    if (heading && heading.parentElement) {
      const parent = heading.parentElement;
      if (panel.parentNode !== parent || panel.previousSibling !== heading) {
        parent.insertBefore(panel, heading.nextSibling);
      }
      fitPanelToTable(panel, table);
      dropBelowHeading(panel, heading);
      if (wasHidden) panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      return;
    }
    if (table && table.parentElement) {
      const parent = table.parentElement;
      if (panel.parentNode !== parent || panel.nextSibling !== table) {
        parent.insertBefore(panel, table);
      }
      fitPanelToTable(panel, table);
      if (wasHidden) panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      return;
    }

    const spot = spotBeforeUcastnici();
    if (spot && (panel.parentNode !== spot.parent || panel.nextSibling !== spot.before)) {
      spot.parent.insertBefore(panel, spot.before);
    } else if (!spot) {
      const root = document.getElementById('root');
      if (root && panel.parentNode !== root) root.appendChild(panel);
    }
    if (wasHidden) panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function fitPanelToTable(panel, table) {
    if (!panel.parentElement) return;
    const parent = panel.parentElement;
    const parentStyle = getComputedStyle(parent);
    const padLeft = parseFloat(parentStyle.paddingLeft) || 0;
    const padRight = parseFloat(parentStyle.paddingRight) || 0;
    const borderLeft = parseFloat(parentStyle.borderLeftWidth) || 0;
    const parentInner = Math.max(0, parent.clientWidth - padLeft - padRight);
    let limit = parentInner || window.innerWidth;
    let node = parent.parentElement;
    while (node && node !== document.documentElement) {
      const style = getComputedStyle(node);
      const overflowX = style.overflowX;
      if ((overflowX === 'auto' || overflowX === 'scroll' || overflowX === 'hidden') && node.clientWidth > 0) {
        limit = Math.min(limit, node.clientWidth);
      }
      node = node.parentElement;
    }
    const contentLeft = parent.getBoundingClientRect().left + borderLeft + padLeft;
    limit = Math.min(limit, Math.max(0, window.innerWidth - Math.max(contentLeft, 0) - 12));
    const tableRect = table ? table.getBoundingClientRect() : null;
    let width = limit;
    if (tableRect && tableRect.width > 40) width = Math.min(tableRect.width, limit);
    width = Math.floor(width);
    if (width < 40) return;
    let shift = 0;
    if (tableRect) {
      shift = Math.max(0, Math.round(tableRect.left - contentLeft));
      if (shift + width > limit + 1) shift = 0;
    }
    panel.style.boxSizing = 'border-box';
    panel.style.width = width + 'px';
    panel.style.maxWidth = '100%';
    panel.style.minWidth = '0';
    panel.style.marginTop = '16px';
    panel.style.marginBottom = '16px';
    panel.style.marginRight = '0';
    panel.style.marginLeft = shift + 'px';
  }

  function dropBelowHeading(panel, heading) {
    const old = document.getElementById('bis-csv-strut');
    const placed = getComputedStyle(heading).position;
    if (placed !== 'absolute' && placed !== 'fixed') {
      old?.remove();
      return;
    }
    let strut = old;
    if (!strut) {
      strut = document.createElement('div');
      strut.id = 'bis-csv-strut';
      strut.setAttribute('aria-hidden', 'true');
      strut.style.display = 'block';
      strut.style.width = '100%';
      strut.style.pointerEvents = 'none';
    }
    if (strut.parentNode !== panel.parentNode || strut.nextSibling !== panel) {
      panel.parentNode.insertBefore(strut, panel);
    }
    strut.style.height = '0px';
    const gap = Math.ceil(heading.getBoundingClientRect().bottom - strut.getBoundingClientRect().top);
    strut.style.height = Math.max(0, gap) + 'px';
  }

  let importRunning = false;
  let owlClosedFor = '';

  function closeGuideOwl() {
    if (!isClosePage()) {
      owlClosedFor = '';
      return;
    }
    const page = location.pathname;
    if (owlClosedFor === page) return;
    const button = document.getElementById('closeOwlGuide');
    if (!button) return;
    button.click();
    owlClosedFor = page;
  }

  function deleteDialogElement(heading) {
    const titled = heading.closest('[role="dialog"], .ReactModal__Content');
    if (titled) return titled;
    let node = heading.parentElement;
    while (node && node !== document.body) {
      const pos = getComputedStyle(node).position;
      if (pos === 'fixed' || pos === 'absolute') return node;
      node = node.parentElement;
    }
    return null;
  }

  function styleDeleteDialogs() {
    if (!isClosePage()) return;
    document.querySelectorAll('h2').forEach(heading => {
      if (!(heading.textContent || '').trim().startsWith('Opravdu chcete smazat')) return;
      const dialog = deleteDialogElement(heading);
      if (!dialog) return;
      dialog.classList.add('bis-delete-dialog');
      dialog.parentElement?.classList.add('bis-delete-overlay');
      if (dialog.dataset.bisLeaving === '1') {
        dialog.classList.add('is-leaving');
        dialog.parentElement?.classList.add('is-leaving');
      }
    });
  }

  function leaveDeleteDialog(dialog, replay) {
    if (!dialog || dialog.dataset.bisLeaving === '1') return;
    dialog.dataset.bisLeaving = '1';
    dialog.classList.add('bis-delete-dialog', 'is-leaving');
    dialog.parentElement?.classList.add('bis-delete-overlay', 'is-leaving');
    setTimeout(() => {
      if (dialog.isConnected) replay();
    }, 240);
  }

  function armDeleteToasts() {
    if (!isClosePage()) return;
    document.querySelectorAll('[class*="_success_"]').forEach(toast => {
      if (!(toast.textContent || '').includes('smazán')) return;
      toast.classList.add('bis-delete-toast');
      if (toast.dataset.bisToast) return;
      toast.dataset.bisToast = '1';
      setTimeout(() => {
        if (!toast.isConnected || toast.classList.contains('is-leaving')) return;
        toast.classList.add('is-leaving');
        setTimeout(() => {
          toast.querySelector('button')?.click();
        }, 240);
      }, 1000);
    });
  }

  function parseParticipantStats(text) {
    const raw = String(text || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
    if (!/Počet /.test(raw) || !/0-6 let=/.test(raw)) return null;
    const num = pattern => {
      const match = raw.match(pattern);
      return match ? Number(match[1]) : 0;
    };
    return {
      total: num(/Počet [^:]+:\s*(\d+)/),
      org: num(/organizátoři=(\d+)/),
      att: num(/účastníci=(\d+)/),
      accepted: num(/přijatí=(\d+)/),
      rejected: num(/zamítnutí=(\d+)/),
      pending: num(/čekající=(\d+)/),
      a06: num(/0-6 let=(\d+)/),
      a715: num(/7-15 let=(\d+)/),
      a1618: num(/16-18 let=(\d+)/),
      a1926: num(/19-26 let=(\d+)/),
      a27: num(/27\+let=(\d+)/),
      under26: num(/celkem do 26 let=(\d+)/),
      unknown: num(/neznámý věk=(\d+)/)
    };
  }

  function renderParticipantStats() {
    if (!isClosePage()) {
      document.getElementById('bis-stats-card')?.remove();
      return;
    }
    let source = '';
    document.querySelectorAll('[class*="StatsContainer"]').forEach(host => {
      if (host.closest('#bis-stats-card, #bis-csv-panel')) return;
      const text = (host.textContent || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
      const participants = /organizátoři=\d+/.test(text) && /0-6 let=/.test(text);
      if (!participants) return;
      source = text;
      host.dataset.bisStatsHidden = '1';
      host.style.setProperty('display', 'none', 'important');
    });
    const stats = parseParticipantStats(source);
    const table = participantTable();
    if (!stats || !table || !table.parentElement) {
      document.getElementById('bis-stats-card')?.remove();
      return;
    }
    let card = document.getElementById('bis-stats-card');
    if (!card) {
      card = document.createElement('div');
      card.id = 'bis-stats-card';
    }
    const sig = JSON.stringify(stats);
    if (card.dataset.sig !== sig) {
      card.dataset.sig = sig;
      card.innerHTML = participantStatsMarkup(stats);
    }
    let anchor = table;
    let node = table.parentElement;
    while (node && node !== document.body) {
      const overflowX = getComputedStyle(node).overflowX;
      if ((overflowX === 'auto' || overflowX === 'scroll') && node.contains(table)) {
        anchor = node;
        break;
      }
      node = node.parentElement;
    }
    const parent = anchor.parentElement;
    if (parent && (card.parentNode !== parent || card.previousSibling !== anchor)) {
      parent.insertBefore(card, anchor.nextSibling);
    }
    fitStatsToPlugin(card);
  }

  function participantStatsMarkup(stats) {
    const splits = [['Organizátoři', stats.org, '#f5b942'], ['Účastníci', stats.att, '#008800']];
    const whole = splits.reduce((sum, item) => sum + item[1], 0) || stats.total || 1;
    let angle = 0;
    const stops = splits.map(item => {
      const next = angle + (item[1] / whole) * 360;
      const stop = `${item[2]} ${angle}deg ${next}deg`;
      angle = next;
      return stop;
    }).join(', ');
    const ages = [
      ['0–6', stats.a06, '#9be7b8'],
      ['7–15', stats.a715, '#008800'],
      ['16–18', stats.a1618, '#0b6b3a'],
      ['19–26', stats.a1926, '#3f7089'],
      ['27+', stats.a27, '#f5b942']
    ];
    if (stats.unknown) ages.push(['Neznámý', stats.unknown, '#c0392b']);
    const maxAge = Math.max(1, ...ages.map(item => item[1]));
    return `
      <div class="bis-stats">
        <div class="bis-stats-top">
          <div class="bis-stats-donut" style="background:conic-gradient(${stops})" role="img" aria-label="${stats.total} účastníků">
            <span>${stats.total}</span>
          </div>
          <div class="bis-stats-copy">
            <div class="bis-stats-kicker">Účastníci</div>
            <div class="bis-stats-legend">
              ${splits.map(item => `<span><i style="background:${item[2]}"></i>${item[0]} <b>${item[1]}</b></span>`).join('')}
            </div>
            <div class="bis-stats-under">
              <span>Do 26 let</span>
              <b>${stats.under26}</b>
              <span class="bis-stats-meter"><span style="width:${stats.total ? Math.round(stats.under26 / stats.total * 100) : 0}%"></span></span>
            </div>
          </div>
        </div>
        <div class="bis-stats-ages">
          ${ages.map(item => `
            <div class="bis-stats-age">
              <span class="bis-stats-age-label">${item[0]}</span>
              <span class="bis-stats-track"><span style="width:${Math.round(item[1] / maxAge * 100)}%;background:${item[2]}"></span></span>
              <span class="bis-stats-age-n">${item[1]}</span>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  function fitStatsToPlugin(card) {
    const panel = document.getElementById('bis-csv-panel');
    const panelWidth = panel && !panel.hidden ? panel.getBoundingClientRect().width : 0;
    if (!panel || panel.hidden || panelWidth < 40) {
      fitPanelToTable(card, participantTable());
      return;
    }
    const parent = card.parentElement;
    if (!parent) return;
    const parentStyle = getComputedStyle(parent);
    const contentLeft = parent.getBoundingClientRect().left
      + (parseFloat(parentStyle.borderLeftWidth) || 0)
      + (parseFloat(parentStyle.paddingLeft) || 0);
    const shift = Math.max(0, Math.round(panel.getBoundingClientRect().left - contentLeft));
    const room = Math.max(0, parent.clientWidth - shift - (parseFloat(parentStyle.paddingRight) || 0));
    const width = Math.floor(Math.min(panelWidth, room || panelWidth));
    card.style.boxSizing = 'border-box';
    card.style.width = width + 'px';
    card.style.maxWidth = '100%';
    card.style.minWidth = '0';
    card.style.marginTop = '16px';
    card.style.marginBottom = '16px';
    card.style.marginRight = '0';
    card.style.marginLeft = shift + 'px';
  }

  function checkAndInject() {
    if (!isClosePage()) {
      owlClosedFor = '';
      removeUI();
      return;
    }
    const id = getEventId() || '';
    const existing = document.getElementById('bis-csv-panel');
    if (existing && existing.dataset.eventId !== id) removeUI();
    if (!document.getElementById('bis-csv-panel')) injectUI();
    layoutPanel();
    restyleParticipants();
    renderParticipantStats();
    styleDeleteDialogs();
    armDeleteToasts();
    closeGuideOwl();
    const todoHost = document.getElementById('bis-csv-todo');
    if (!importRunning && todoHost && todoHost.hidden) {
      const saved = readTodoState();
      if (saved.items.some(person => !person.done)) {
        showManualTodo(saved.items, { reloadAfter: saved.reloadAfter });
      }
    }
  }

  const _pushState = history.pushState.bind(history);
  history.pushState = function (...args) { _pushState(...args); setTimeout(checkAndInject, 50); };
  const _replaceState = history.replaceState.bind(history);
  history.replaceState = function (...args) { _replaceState(...args); setTimeout(checkAndInject, 50); };
  window.addEventListener('popstate', () => setTimeout(checkAndInject, 50));
  window.addEventListener('resize', () => {
    if (!isClosePage()) return;
    layoutPanel();
    renderParticipantStats();
  });
  setInterval(checkAndInject, 400);
  document.addEventListener('mouseover', event => {
    if (!isClosePage()) return;
    const row = event.target instanceof Element ? event.target.closest('tr') : null;
    if (!row || row.closest('#bis-csv-panel, #bis-dup-modal')) return;
    const table = participantTable();
    if (!table || !table.contains(row)) return;
    setTimeout(() => {
      const current = participantTable();
      if (current) markDuplicateImports(current);
    }, 0);
  });

  let checkTimer = null;
  function scheduleCheck() {
    clearTimeout(checkTimer);
    checkTimer = setTimeout(checkAndInject, 60);
  }

  const appRoot = document.getElementById('root');
  if (appRoot) {
    new MutationObserver(() => {
      if (isClosePage()) scheduleCheck();
      else removeUI();
    }).observe(appRoot, { childList: true, subtree: true });
  }
  if (document.body) {
    new MutationObserver(() => {
      if (!isClosePage()) return;
      styleDeleteDialogs();
      armDeleteToasts();
    }).observe(document.body, { childList: true, subtree: true });
  }

  document.addEventListener('click', event => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    const dialog = target.closest('.bis-delete-dialog');
    const overlay = target.classList.contains('bis-delete-overlay') ? target : null;
    const dialogEl = dialog || overlay?.querySelector('.bis-delete-dialog');
    if (!dialogEl || dialogEl.dataset.bisLeaving === '1') return;
    const button = target.closest('button');
    const closer = target.closest('svg');
    if (!button && !closer && !overlay) return;
    if (button?.closest('#bis-csv-panel, #bis-dup-modal')) return;
    event.preventDefault();
    event.stopPropagation();
    leaveDeleteDialog(dialogEl, () => {
      if (button) button.click();
      else if (closer) closer.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
      else overlay.click();
    });
  }, true);

  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;
    const dialog = document.querySelector('.bis-delete-dialog');
    if (!dialog || dialog.dataset.bisLeaving === '1') return;
    event.preventDefault();
    event.stopPropagation();
    const closer = dialog.querySelector('svg');
    leaveDeleteDialog(dialog, () => {
      if (closer) closer.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
    });
  }, true);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', checkAndInject);
  } else {
    checkAndInject();
  }

  function formatParticipantName(value) {
    const text = String(value || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
    const match = text.match(/^(.+?)\(([^)]+)\)\s+(.+)$/);
    if (!match) return '';
    const first = match[1].trim();
    const nick = match[2].trim();
    const last = match[3].trim();
    if (!first || !nick || !last || /[()]/.test(first) || /[()]/.test(last) || /\d/.test(last)) return '';
    return first + ' ' + last + ' – ' + nick;
  }

  function renameParticipantHeadings() {
    const heading = participantHeading();
    if (!heading) return;
    heading.setAttribute('data-bis-ucastnictvo', '');
    const walker = document.createTreeWalker(heading, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      const node = walker.currentNode;
      if (node.nodeValue && node.nodeValue.includes('Účastníci')) {
        node.nodeValue = node.nodeValue.replace('Účastníci', 'Účastnictvo');
      }
    }
  }

  function rewriteNameCell(cell) {
    const current = elementText(cell);
    const next = formatParticipantName(current);
    if (!next || next === current) return;
    const textNodes = [...cell.childNodes].filter(node => node.nodeType === Node.TEXT_NODE && node.nodeValue.trim());
    if (textNodes.length) {
      textNodes[0].nodeValue = next;
      textNodes.slice(1).forEach(node => { node.nodeValue = ''; });
      [...cell.childNodes].forEach(node => {
        if (node.nodeType === Node.TEXT_NODE && !node.nodeValue.trim()) node.nodeValue = '';
      });
      return;
    }
    const nodes = [cell, ...cell.querySelectorAll('*')];
    const leaf = nodes.reverse().find(el => el.children.length === 0 && elementText(el) === current);
    if (leaf) leaf.textContent = next;
    else cell.textContent = next;
  }

  function participantNameRoot() {
    const root = document.getElementById('root');
    if (!root) return null;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const starts = [];
    while (walker.nextNode()) {
      const value = walker.currentNode.nodeValue.replace(/\s+/g, ' ').trim();
      if (value.toLowerCase() !== 'adresa') continue;
      const el = walker.currentNode.parentElement;
      if (!el || el.closest('#bis-csv-panel, #bis-dup-modal, #bis-csv-strut')) continue;
      starts.push(el);
    }
    for (const start of starts) {
      let node = start;
      let best = null;
      while (node && node !== root) {
        const text = elementText(node);
        const plain = text.toLowerCase();
        const hasNames = plain.includes('jméno a příjmení') && /\([^)]+\)/.test(text);
        if (hasNames) best = node;
        const parent = node.parentElement;
        if (!parent || parent === root) break;
        const parentPlain = elementText(parent).toLowerCase();
        if (best && !plain.includes('datum podání') && parentPlain.includes('datum podání')) break;
        node = parent;
      }
      if (best) return best;
    }
    return null;
  }

  function rewriteNameText(container) {
    const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(node => {
      const parent = node.parentElement;
      if (!parent || parent.closest('#bis-csv-panel, #bis-dup-modal, #bis-csv-strut')) return;
      const raw = node.nodeValue.replace(/\u00a0/g, ' ');
      const trimmed = raw.replace(/\s+/g, ' ').trim();
      const next = formatParticipantName(trimmed);
      if (!next || next === trimmed) return;
      node.nodeValue = raw.replace(trimmed, next);
    });
  }

  function restyleParticipants() {
    if (!isClosePage()) return;
    renameParticipantHeadings();
    const area = participantNameRoot();
    if (area) {
      rewriteNameText(area);
      [...area.querySelectorAll('a, span, div, td, p')].forEach(el => {
        if (el.closest('#bis-csv-panel, #bis-dup-modal, #bis-csv-strut')) return;
        if (el.children.length > 4) return;
        const current = elementText(el);
        const next = formatParticipantName(current);
        if (!next || next === current) return;
        if ([...el.children].some(child => elementText(child) === current)) return;
        el.textContent = next;
      });
    }
    const table = participantTable();
    if (!table) return;
    const header = [...table.querySelectorAll('th, td, [role="columnheader"]')].find(el => elementText(el).toLowerCase() === 'jméno a příjmení');
    if (!header || !header.parentElement) return;
    const index = [...header.parentElement.children].indexOf(header);
    if (index < 0) return;
    [...table.querySelectorAll('tr, [role="row"]')].forEach(row => {
      if (row.contains(header)) return;
      const cell = row.children[index];
      if (cell) rewriteNameCell(cell);
    });
    markDuplicateImports(table);
  }

  function personMatchKey(name, birthday) {
    let text = String(name || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
    text = text.replace(/\s+[–—-]\s+\S.*$/, '').trim();
    text = text.replace(/\([^)]*\)/g, ' ').replace(/\s+/g, ' ').trim();
    const born = String(birthday || '').replace(/\s+/g, ' ').trim().toLowerCase();
    if (!text || !born || born.length > 40) return '';
    return text + '|' + born;
  }

  function rowIsOrganizer(row) {
    return [...row.querySelectorAll('div, span')].some(el => elementText(el) === 'ORG' && el.children.length === 0);
  }

  function paintDuplicateCell(el) {
    el.style.setProperty('background-color', '#ffe8e6', 'important');
    el.style.setProperty('background-image', 'none', 'important');
  }

  function clearDuplicateMark(row) {
    row.classList.remove('bis-dup-row');
    row.style.removeProperty('background-color');
    row.style.removeProperty('background-image');
    row.style.removeProperty('background');
    row.style.removeProperty('box-shadow');
    row.querySelectorAll('td, th').forEach(cell => {
      cell.style.removeProperty('background-color');
      cell.style.removeProperty('background-image');
      cell.style.removeProperty('background');
    });
    row.querySelectorAll('button.bis-dup-trash, button[aria-label^="Smazat účastníka"]').forEach(btn => {
      btn.classList.remove('bis-dup-trash');
      ['width', 'height', 'min-width', 'min-height'].forEach(prop => btn.style.removeProperty(prop));
      const icon = btn.querySelector('svg');
      if (icon) {
        icon.style.removeProperty('width');
        icon.style.removeProperty('height');
      }
    });
  }

  function markDuplicateRow(row) {
    row.classList.add('bis-dup-row');
    paintDuplicateCell(row);
    row.querySelectorAll('td, th').forEach(paintDuplicateCell);
    const buttons = [...row.querySelectorAll('button[aria-label^="Smazat účastníka"]')];
    const btn = buttons.find(button => !button.closest('[class*="disabled"]')) || buttons[buttons.length - 1];
    if (btn) btn.classList.add('bis-dup-trash');
  }

  function markDuplicateImports(table) {
    const rows = [...table.querySelectorAll('tr')].filter(row => !row.querySelector('th'));
    rows.forEach(clearDuplicateMark);
    const groups = new Map();
    rows.forEach(row => {
      const cells = [...row.children];
      if (cells.length < 2) return;
      const key = personMatchKey(elementText(cells[0]), elementText(cells[1]));
      if (!key) return;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(row);
    });
    groups.forEach(list => {
      if (list.length < 2) return;
      const hasOrganizer = list.some(rowIsOrganizer);
      list.forEach((row, index) => {
        const extra = hasOrganizer ? !rowIsOrganizer(row) : index > 0;
        if (extra) markDuplicateRow(row);
      });
    });
  }

  function getEventId() {
    return location.pathname.match(/^\/org\/akce\/(\d+)\/uzavrit\/?$/)?.[1] || null;
  }

  function injectUI() {
    if (document.getElementById('bis-csv-panel')) return;

    const eventId = getEventId();
    const logoSrc = chrome.runtime.getURL('levitio-logo.png');
    const panel = document.createElement('div');
    panel.id = 'bis-csv-panel';
    panel.dataset.eventId = eventId || '';
    panel.hidden = true;
    panel.innerHTML = `
      <div class="bis-csv-head">
        <img class="bis-csv-logo" alt="Levitio" src="${logoSrc}">
        <div class="bis-csv-head-text">
          <div class="bis-csv-title">Import z Levitia</div>
          <p class="bis-csv-hint">Vlož XLSX soubor s účastníky z Levitia se sloupci Jméno, Příjmení a Narození. Tito účastníci se přidají do BISu.</p>
        </div>
        <a class="bis-csv-about" href="https://oddiltitio.cz/aplikace/bis" target="_blank" rel="noopener noreferrer">Více o pluginu</a>
      </div>
      <div id="bis-csv-tools">
        <div class="bis-csv-actions">
          <label class="bis-csv-file-btn" for="bis-csv-file">Nahrát soubor</label>
          <span class="bis-csv-filename" id="bis-csv-filename">Žádný soubor</span>
          <button class="bis-csv-run-btn" id="bis-csv-run" type="button" disabled>Spustit import</button>
          <input type="file" id="bis-csv-file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet">
        </div>
        <div class="bis-csv-progress" id="bis-csv-progress" style="display:none">
          <div class="bis-csv-progress-bar" id="bis-csv-progress-bar"></div>
        </div>
        <div class="bis-csv-log" id="bis-csv-log"></div>
      </div>
      <div id="bis-csv-todo" hidden></div>
    `;
    document.body.appendChild(panel);

    const fileInput = document.getElementById('bis-csv-file');
    const filenameEl = document.getElementById('bis-csv-filename');
    const runBtn = document.getElementById('bis-csv-run');
    let parsedRows = [];

    fileInput.addEventListener('change', () => {
      const file = fileInput.files[0];
      if (!file) return;
      filenameEl.textContent = file.name;
      runBtn.disabled = true;
      runBtn.textContent = 'Načítám…';
      const reader = new FileReader();
      reader.onload = () => {
        const logEl = document.getElementById('bis-csv-log');
        if (logEl) logEl.innerHTML = '';
        document.getElementById('bis-dup-modal')?.remove();
        try {
          if (typeof XLSX === 'undefined' || typeof BisConvert === 'undefined') {
            throw new Error('Převodník se nenačetl. Rozšíření znovu načti v Brave.');
          }
          const workbook = XLSX.read(reader.result, { type: 'array', cellDates: false });
          const sheetName = workbook.SheetNames[0];
          const rows = BisConvert.sheetToRows(XLSX, workbook, sheetName);
          const result = BisConvert.convertRows(rows);
          if (!result.ok) {
            parsedRows = [];
            runBtn.disabled = true;
            runBtn.textContent = 'Spustit import';
            log(result.error, 'error');
            return;
          }
          parsedRows = result.attendees.map(person => [
            person.first_name,
            person.last_name,
            person.email,
            person.phone,
            person.birthday,
            person.nickname
          ]);
          result.warnings.forEach(warning => log(warning, 'warn'));
          log(`Převedeno ${parsedRows.length} účastníků z listu ${sheetName}.`, 'info');
          runBtn.disabled = !eventId || parsedRows.length === 0;
          runBtn.textContent = `Spustit import (${parsedRows.length} osob)`;
        } catch (err) {
          parsedRows = [];
          runBtn.disabled = true;
          runBtn.textContent = 'Spustit import';
          log(err && err.message ? err.message : 'Tenhle soubor nejde otevřít jako sešit Excelu.', 'error');
        }
      };
      reader.onerror = () => {
        parsedRows = [];
        runBtn.disabled = true;
        runBtn.textContent = 'Spustit import';
        log('Soubor se nepodařilo načíst.', 'error');
      };
      reader.readAsArrayBuffer(file);
    });

    runBtn.addEventListener('click', async () => {
      const dataRows = parsedRows.slice();
      importRunning = true;
      writeTodoState([], false);
      revealImportTools();
      runBtn.disabled = true;
      runBtn.textContent = 'Probíhá import…';
      try {
        await runImport(dataRows);
      } finally {
        importRunning = false;
        if (runBtn.isConnected && document.getElementById('bis-csv-todo')?.hidden !== false) {
          runBtn.disabled = false;
          runBtn.textContent = parsedRows.length ? `Spustit znovu (${parsedRows.length} osob)` : 'Spustit znovu';
        }
      }
    });
  }

  function getAuthToken() {
    try {
      const raw = localStorage.getItem('persist:auth');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed.token) return JSON.parse(parsed.token);
      }
    } catch (e) {}
    return null;
  }

  function getCsrfToken() {
    return document.cookie.match(/csrftoken=([^;]+)/)?.[1] || '';
  }

  function apiHeaders(withBody = false) {
    const token = getAuthToken();
    const h = { 'X-CSRFToken': getCsrfToken() };
    if (token) h['Authorization'] = `Token ${token}`;
    if (withBody) h['Content-Type'] = 'application/json';
    return h;
  }

  async function apiFetch(url, opts = {}) {
    const resp = await fetch(url, { credentials: 'include', headers: apiHeaders(), ...opts });
    const text = await resp.text();
    if (!resp.ok) {
      const isHtml = text.trimStart().startsWith('<');
      if (isHtml) throw new Error(`Server nedostupný (${resp.status}) – zkus znovu za chvíli`);
      throw new Error(`API error ${resp.status}: ${text.slice(0, 150)}`);
    }
    try { return JSON.parse(text); }
    catch (e) { throw new Error('Server vrátil neplatnou odpověď – zkus znovu za chvíli'); }
  }

  async function searchUsers(first, last) {
    const q = encodeURIComponent(`${first} ${last}`);
    const d1 = await apiFetch(`/api/frontend/search_users/?search=${q}`);
    const searchResults = d1.results || [];
    if (searchResults.length === 0) return [];
    const searchIds = searchResults.map(u => u._search_id).filter(Boolean).join(',');
    const d2 = await apiFetch(`/api/frontend/users/?_search_id=${encodeURIComponent(searchIds)}&page_size=2000`);
    return d2.results || [];
  }

  async function getCurrentParticipants() {
    const eventId = getEventId();
    const data = await apiFetch(`/api/frontend/events/${eventId}/record/participants/?page_size=10000`);
    const results = data.results || [];

    const ids = results.map(p => {
      if (typeof p === 'string') return p;
      if (p.user_id) return p.user_id;
      if (p.user?.id) return p.user.id;
      if (p.user && typeof p.user === 'string') return p.user;
      if (p.id) return p.id;
      return null;
    }).filter(Boolean);

    if (results.length > 0) {
      console.log('[BIS] participant objekt:', JSON.stringify(results[0]).slice(0, 200));
    }

    return ids;
  }

  async function patchParticipants(ids) {
    const eventId = getEventId();
    return apiFetch(`/api/frontend/events/${eventId}/`, {
      method: 'PATCH',
      headers: apiHeaders(true),
      body: JSON.stringify({
        record: {
          participants: ids,
          contacts: [],
          number_of_participants: null,
          number_of_participants_under_26: null
        }
      })
    });
  }

  function matchUser(results, csvRow) {
    const first = (csvRow[0] || '').trim().toLowerCase();
    const last = (csvRow[1] || '').trim().toLowerCase();
    const birthday = (csvRow[4] || '').trim();
    const nickname = (csvRow[5] || '').trim().toLowerCase();

    let candidates = results.filter(u =>
      u.first_name?.toLowerCase() === first &&
      u.last_name?.toLowerCase() === last
    );
    if (candidates.length === 0) return null;
    if (candidates.length === 1) return { user: candidates[0], certain: true, matchedBy: 'jméno+příjmení' };

    if (birthday) {
      const byBd = candidates.filter(u => u.birthday === birthday);
      if (byBd.length === 1) return { user: byBd[0], certain: true, matchedBy: 'jméno+příjmení+datum' };
      if (byBd.length > 1) candidates = byBd;
    }

    if (nickname) {
      const byNick = candidates.filter(u => u.nickname?.toLowerCase() === nickname);
      if (byNick.length === 1) return { user: byNick[0], certain: true, matchedBy: 'jméno+příjmení+přezdívka' };
    }

    return {
      user: candidates[0],
      certain: false,
      matchedBy: 'jméno+příjmení (více shod)',
      allCandidates: candidates
    };
  }

  function log(msg, type = 'info') {
    const el = document.getElementById('bis-csv-log');
    if (!el) return;
    const line = document.createElement('div');
    line.className = `bis-log-line bis-log-${type}`;
    line.textContent = msg;
    el.appendChild(line);
    el.scrollTop = el.scrollHeight;
  }

  function setProgress(done, total) {
    const wrap = document.getElementById('bis-csv-progress');
    const bar = document.getElementById('bis-csv-progress-bar');
    if (!wrap || !bar) return;
    wrap.style.display = 'block';
    bar.style.width = `${total > 0 ? Math.round((done / total) * 100) : 0}%`;
  }

  function humanBirthday(value) {
    const text = String(value || '').trim();
    if (!text) return '';
    let day;
    let month;
    let year;
    let match = text.match(/(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (match) {
      year = Number(match[1]);
      month = Number(match[2]);
      day = Number(match[3]);
    } else {
      match = text.match(/(\d{1,2})\s*[.\-/]\s*(\d{1,2})\s*[.\-/]\s*(\d{4})/);
      if (!match) return '';
      day = Number(match[1]);
      month = Number(match[2]);
      year = Number(match[3]);
    }
    if (!year || month < 1 || month > 12 || day < 1 || day > 31) return '';
    return day + '. ' + CZECH_MONTHS[month - 1] + ' ' + year;
  }

  function todoStorageKey() {
    const id = getEventId();
    return id ? 'bis-levitio-todo-' + id : '';
  }

  function readTodoState() {
    const key = todoStorageKey();
    if (!key) return { reloadAfter: false, items: [] };
    try {
      const parsed = JSON.parse(sessionStorage.getItem(key) || 'null');
      if (!parsed || !Array.isArray(parsed.items)) return { reloadAfter: false, items: [] };
      return { reloadAfter: !!parsed.reloadAfter, items: parsed.items };
    } catch (e) {
      return { reloadAfter: false, items: [] };
    }
  }

  function writeTodoState(items, reloadAfter) {
    const key = todoStorageKey();
    if (!key) return;
    if (!items.length) sessionStorage.removeItem(key);
    else sessionStorage.setItem(key, JSON.stringify({ reloadAfter: !!reloadAfter, items: items }));
  }

  function revealImportTools() {
    const panel = document.getElementById('bis-csv-panel');
    const host = document.getElementById('bis-csv-todo');
    const tools = document.getElementById('bis-csv-tools');
    const intro = panel?.querySelector('.bis-csv-head');
    if (host) {
      host.hidden = true;
      host.classList.remove('is-leaving');
      host.replaceChildren();
    }
    if (tools) tools.hidden = false;
    if (intro) intro.hidden = false;
    panel?.classList.remove('is-warning');
    const runBtn = document.getElementById('bis-csv-run');
    if (runBtn && !importRunning) {
      runBtn.disabled = false;
      if (runBtn.textContent === 'Probíhá import…') runBtn.textContent = 'Spustit znovu';
    }
  }

  function showManualTodo(people, options) {
    const host = document.getElementById('bis-csv-todo');
    const panel = document.getElementById('bis-csv-panel');
    if (!host || !panel || !host.hidden) return;
    const reloadAfter = !!(options && options.reloadAfter);
    const items = (people || [])
      .map(person => ({
        first: String(person.first || '').trim(),
        last: String(person.last || '').trim(),
        birthday: String(person.birthday || '').trim(),
        done: !!person.done
      }))
      .filter(person => person.first || person.last);
    if (!items.length || items.every(person => person.done)) {
      writeTodoState([], false);
      return;
    }

    writeTodoState(items, reloadAfter);
    document.getElementById('bis-dup-modal')?.remove();

    host.replaceChildren();
    const head = document.createElement('div');
    head.className = 'bis-todo-head';
    head.innerHTML = `
      <div class="bis-todo-title">Někteří se nepřidali</div>
      <p class="bis-todo-lead">Tyhle účastníky je potřeba přidat ručně. Až je v seznamu odškrtneš všechny, zmizí.</p>
      <div class="bis-todo-progress">
        <span class="bis-todo-count"></span>
        <span class="bis-todo-track"><span class="bis-todo-fill"></span></span>
      </div>
    `;
    const list = document.createElement('div');
    list.className = 'bis-todo-list';
    host.appendChild(head);
    host.appendChild(list);
    items.forEach(person => {
      const label = document.createElement('label');
      label.className = 'bis-todo-item' + (person.done ? ' is-done' : '');
      const input = document.createElement('input');
      input.type = 'checkbox';
      input.checked = person.done;
      const box = document.createElement('span');
      box.className = 'bis-todo-check';
      box.innerHTML = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3.5 8.2 6.4 11 12.5 4.5" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      const text = document.createElement('span');
      text.className = 'bis-todo-person';
      const name = document.createElement('span');
      name.className = 'bis-todo-name';
      const first = document.createElement('span');
      first.className = 'bis-todo-first';
      first.textContent = person.first;
      const last = document.createElement('span');
      last.className = 'bis-todo-last';
      last.textContent = person.last;
      name.appendChild(first);
      if (person.first && person.last) name.appendChild(document.createTextNode(' '));
      name.appendChild(last);
      text.appendChild(name);
      const dateText = humanBirthday(person.birthday);
      if (dateText) {
        const date = document.createElement('span');
        date.className = 'bis-todo-date';
        date.textContent = dateText;
        text.appendChild(date);
      }
      label.appendChild(input);
      label.appendChild(box);
      label.appendChild(text);
      input.addEventListener('change', () => {
        person.done = input.checked;
        label.classList.toggle('is-done', person.done);
        writeTodoState(items, reloadAfter);
        updateTodoProgress();
        if (items.every(item => item.done)) finishTodo();
      });
      list.appendChild(label);
    });

    function updateTodoProgress() {
      const done = items.filter(item => item.done).length;
      const count = host.querySelector('.bis-todo-count');
      const fill = host.querySelector('.bis-todo-fill');
      if (count) count.textContent = 'Odškrtnuto ' + done + ' z ' + items.length;
      if (fill) fill.style.width = Math.round((done / items.length) * 100) + '%';
    }

    function setImportToolsVisible(visible) {
      const tools = document.getElementById('bis-csv-tools');
      const intro = panel.querySelector('.bis-csv-head');
      if (tools) tools.hidden = !visible;
      if (intro) intro.hidden = !visible;
      host.hidden = visible;
      panel.classList.toggle('is-warning', !visible);
      if (visible) {
        const runBtn = document.getElementById('bis-csv-run');
        if (runBtn) {
          runBtn.disabled = false;
          runBtn.textContent = 'Spustit znovu';
        }
      }
    }

    let finishing = false;
    function finishTodo() {
      if (finishing) return;
      finishing = true;
      writeTodoState([], false);
      host.classList.add('is-leaving');
      setTimeout(() => {
        host.classList.remove('is-leaving');
        host.replaceChildren();
        setImportToolsVisible(true);
        if (reloadAfter) location.reload();
      }, 280);
    }

    updateTodoProgress();
    setImportToolsVisible(false);
    host.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  async function runImport(rows) {
    document.getElementById('bis-csv-log').innerHTML = '';
    const eventId = getEventId();
    if (!eventId) { log('ID akce nenalezeno v URL.', 'error'); return; }

    log('Načítám stávající účastníky…', 'info');
    let existingIds;
    try {
      existingIds = await getCurrentParticipants();
      if (existingIds.length > 0) {
        log(`Zachovávám ${existingIds.length} stávající účastník${existingIds.length === 1 ? 'a' : existingIds.length < 5 ? 'y' : 'ů'}.`, 'info');
      } else {
        log('Žádní stávající účastníci.', 'info');
      }
    } catch (e) {
      log(e.message, 'error');
      return;
    }

    const existingSet = new Set(existingIds);
    const toAdd = [];
    const uncertain = [];
    const notFound = [];
    let alreadyIn = 0;

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const first = (row[0] || '').trim();
      const last = (row[1] || '').trim();
      const birthday = (row[4] || '').trim();
      const nickname = (row[5] || '').trim();
      const csvName = `${first} ${last}${nickname ? ` (${nickname})` : ''}`;

      setProgress(i, rows.length);
      log(csvName, 'info');

      try {
        const results = await searchUsers(first, last);

        if (!results || results.length === 0) {
          log(`Nenalezeno: ${csvName}`, 'warn');
          notFound.push({ first, last, birthday });
          continue;
        }

        const match = matchUser(results, row);

        if (!match) {
          log(`Žádná shoda: ${csvName}`, 'warn');
          notFound.push({ first, last, birthday });
          continue;
        }

        const uuid = match.user.id;

        if (existingSet.has(uuid)) {
          log(`Již přidán: ${csvName}`, 'info');
          alreadyIn++;
          continue;
        }

        if (!match.certain) {
          const selectedName = `${match.user.first_name} ${match.user.last_name}`;
          const others = (match.allCandidates || [])
            .filter(u => u.id !== uuid)
            .map(u => `${u.first_name} ${u.last_name}${u.birthday ? ` (nar. ${u.birthday})` : ''}${u.nickname ? `, přezdívka: ${u.nickname}` : ''}`);
          log(`Více shod pro „${csvName}“ – přidána: ${selectedName}. Ověř ručně.`, 'warn');
          uncertain.push({ csvName, selectedName, birthday: match.user.birthday, nickname: match.user.nickname, others });
        } else {
          log(`${csvName} (${match.matchedBy})`, 'ok');
        }

        toAdd.push(uuid);
        existingSet.add(uuid);

      } catch (e) {
        log(`Chyba u „${csvName}“: ${e.message}`, 'error');
        notFound.push({ first, last, birthday });
      }
    }

    setProgress(rows.length, rows.length);

    if (toAdd.length === 0) {
      log('────────────────────────────────────', 'info');
      if (notFound.length) {
        log(`Hotovo: ${notFound.length} se nepodařilo přidat. Přidej je ručně.${alreadyIn ? ` (${alreadyIn} již bylo)` : ''}`, 'summary');
        try { showManualTodo(notFound, { reloadAfter: false }); }
        catch (err) { log(`Seznam se neotevřel: ${err.message}`, 'error'); }
      } else {
        log(`Hotovo: nikdo nový k přidání.${alreadyIn ? ` (${alreadyIn} již bylo)` : ''}`, 'summary');
      }
      return;
    }

    log(`Odesílám: ${existingIds.length} stávajících + ${toAdd.length} nových…`, 'info');
    const allIds = [...existingIds, ...toAdd];

    try {
      await patchParticipants(allIds);
      log('────────────────────────────────────', 'info');
      log(
        `Hotovo: ${toAdd.length} přidáno` +
        (alreadyIn ? ` | ${alreadyIn} již bylo` : '') +
        (notFound.length ? ` | ${notFound.length} nenalezeno` : '') +
        (uncertain.length ? ` | ${uncertain.length}× nejistá shoda` : ''),
        'summary'
      );
      if (notFound.length) {
        try { showManualTodo(notFound, { reloadAfter: true }); }
        catch (err) { log(`Seznam se neotevřel: ${err.message}`, 'error'); }
      }
      else setTimeout(() => location.reload(), 1500);
    } catch (e) {
      log(`Uložení selhalo: ${e.message}`, 'error');
    }
  }

})();
